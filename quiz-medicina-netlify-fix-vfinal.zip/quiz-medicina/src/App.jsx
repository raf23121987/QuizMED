import React from 'react'
import Quiz from './components/Quiz'
import { Stethoscope, GraduationCap } from 'lucide-react'
import './App.css'

function App() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-3">
              <div className="flex items-center space-x-2">
                <Stethoscope className="h-8 w-8 text-blue-600" />
                <GraduationCap className="h-8 w-8 text-indigo-600" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">Quiz de Medicina</h1>
                <p className="text-sm text-gray-600">Oncologia - Banco de 200+ Questões</p>
              </div>
            </div>
            <div className="text-sm text-gray-500">
              Estudantes de Medicina
            </div>
          </div>
        </div>
      </header>
      
      <main className="py-8">
        <Quiz />
      </main>
      
      <footer className="bg-white border-t mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="text-center space-y-2">
            <p className="text-sm text-gray-500">
              Sistema de Quiz Interativo para Estudantes de Medicina
            </p>
            <p className="text-sm text-gray-500">
              Baseado em materiais acadêmicos de Oncologia
            </p>
            <div className="border-t pt-4 mt-4">
              <p className="text-sm font-medium text-gray-700">
                Criado por <span className="text-blue-600 font-semibold">Rômulo Aguiar Figueiredo</span>
              </p>
              <p className="text-xs text-gray-500 mt-1">
                © 2025 - Todos os direitos reservados. Proibida a reprodução total ou parcial sem autorização.
              </p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}

export default App
