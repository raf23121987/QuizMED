import React, { useState, useEffect, useMemo } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { CheckCircle, XCircle, RotateCcw, BookOpen, Trophy, Target, Clock, AlertTriangle } from 'lucide-react';
import { questoes, selecionarQuestoes } from '../data/questoes';

const Quiz = () => {
  const [questoesAtivas, setQuestoesAtivas] = useState([]);
  // === Controles de personalização ===
  const [quantidade, setQuantidade] = useState(QUESTOES_POR_QUIZ);
  const todasCategorias = Array.from(new Set(questoes.map(q => q.categoria))).sort();
  const [categoriasSelecionadas, setCategoriasSelecionadas] = useState(todasCategorias);
  const dificuldadesDisponiveis = ['baixa','média','alta'];
  const [dificuldadesSelecionadas, setDificuldadesSelecionadas] = useState(dificuldadesDisponiveis);
  const [showPainel, setShowPainel] = useState(true);

  // Persistência em localStorage
  const STORAGE_KEYS = { quantidade: 'quiz_quantidade', categorias: 'quiz_categorias', dificuldades: 'quiz_dificuldades' };
  useEffect(() => {
    try {
      const q = Number(localStorage.getItem(STORAGE_KEYS.quantidade));
      if (!Number.isNaN(q) && q > 0) setQuantidade(Math.max(q, QUESTOES_POR_QUIZ));
      const cats = JSON.parse(localStorage.getItem(STORAGE_KEYS.categorias) || "null");
      if (Array.isArray(cats) && cats.length) setCategoriasSelecionadas(cats);
      const difs = JSON.parse(localStorage.getItem(STORAGE_KEYS.dificuldades) || "null");
      if (Array.isArray(difs) && difs.length) setDificuldadesSelecionadas(difs);
    } catch {}
  }, []);
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.quantidade, String(quantidade));
      localStorage.setItem(STORAGE_KEYS.categorias, JSON.stringify(categoriasSelecionadas));
      localStorage.setItem(STORAGE_KEYS.dificuldades, JSON.stringify(dificuldadesSelecionadas));
    } catch {}
  }, [quantidade, categoriasSelecionadas, dificuldadesSelecionadas]);

  // Contagens
  const contagensPorCategoria = useMemo(() => {
    const mapa = {};
    for (const q of questoes) {
      if (!mapa[q.categoria]) mapa[q.categoria] = { total: 0, baixa: 0, média: 0, alta: 0 };
      mapa[q.categoria].total++;
      mapa[q.categoria][q.complexidade]++;
    }
    return mapa;
  }, []);
  const contagensPorDificuldade = useMemo(() => {
    const mapa = { baixa: 0, média: 0, alta: 0 };
    for (const q of questoes) mapa[q.complexidade]++;
    return mapa;
  }, []);
  const disponiveisFiltrados = useMemo(() => {
    return questoes.filter(q => categoriasSelecionadas.includes(q.categoria) && dificuldadesSelecionadas.includes(q.complexidade)).length;
  }, [categoriasSelecionadas, dificuldadesSelecionadas]);

  const [questaoAtual, setQuestaoAtual] = useState(0);
  const [respostas, setRespostas] = useState({});
  const [mostrarResultado, setMostrarResultado] = useState(false);
  const [quizFinalizado, setQuizFinalizado] = useState(false);
  const [respostaSelecionada, setRespostaSelecionada] = useState(null);
  const [respostasMultiplas, setRespostasMultiplas] = useState([]);
  const [timerIniciado, setTimerIniciado] = useState(false);
  const [tempoRestante, setTempoRestante] = useState(40 * 60); // 40 minutos em segundos
  const [timerAtivo, setTimerAtivo] = useState(false);

  useEffect(() => {
    const questoesIniciais = selecionarQuestoes(30);
    setQuestoesAtivas(questoesIniciais);
  }, []);

  // Timer effect
  useEffect(() => {
    let interval = null;
    if (timerAtivo && tempoRestante > 0) {
      interval = setInterval(() => {
        setTempoRestante(tempo => {
          if (tempo <= 1) {
            setQuizFinalizado(true);
            setTimerAtivo(false);
            return 0;
          }
          return tempo - 1;
        });
      }, 1000);
    } else if (tempoRestante === 0) {
      setQuizFinalizado(true);
      setTimerAtivo(false);
    }
    return () => clearInterval(interval);
  }, [timerAtivo, tempoRestante]);

  const iniciarNovoQuiz = () => {
    const novasQuestoes = selecionarQuestoes(30);
    setQuestoesAtivas(novasQuestoes);
    setQuestaoAtual(0);
    setRespostas({});
    setMostrarResultado(false);
    setQuizFinalizado(false);
    setRespostaSelecionada(null);
    setRespostasMultiplas([]);
    setTimerIniciado(false);
    setTempoRestante(40 * 60);
    setTimerAtivo(false);
  };

  const iniciarTimer = () => {
    if (!timerIniciado) {
      setTimerIniciado(true);
      setTimerAtivo(true);
    }
  };

  const formatarTempo = (segundos) => {
    const minutos = Math.floor(segundos / 60);
    const segs = segundos % 60;
    return `${minutos.toString().padStart(2, '0')}:${segs.toString().padStart(2, '0')}`;
  };

  const aplicarFiltros = () => {
    const filtro = (q) => categoriasSelecionadas.includes(q.categoria) && dificuldadesSelecionadas.includes(q.complexidade);
    setQuestoesAtivas(selecionarQuestoes(Number(quantidade), filtro));
    setQuestaoAtual(0); setRespostas({}); setMostrarResultado(false); setQuizFinalizado(false); setRespostaSelecionada(null); setRespostasMultiplas([]);
  };
  const toggleCategoria = (cat) => setCategoriasSelecionadas(prev => prev.includes(cat) ? prev.filter(c=>c!==cat) : [...prev, cat]);
  const toggleDificuldade = (dif) => setDificuldadesSelecionadas(prev => prev.includes(dif) ? prev.filter(d=>d!==dif) : [...prev, dif]);
  const resetPreferencias = () => {
    try { localStorage.removeItem('quiz_quantidade'); localStorage.removeItem('quiz_categorias'); localStorage.removeItem('quiz_dificuldades'); } catch {}
    setQuantidade(QUESTOES_POR_QUIZ); setCategoriasSelecionadas(todasCategorias); setDificuldadesSelecionadas(dificuldadesDisponiveis); aplicarFiltros();
  };

  const handleResposta = (resposta) => {
    const questao = questoesAtivas[questaoAtual];
    
    if (questao.tipo === 'multiplas_corretas') {
      const novasRespostasMultiplas = respostasMultiplas.includes(resposta)
        ? respostasMultiplas.filter(r => r !== resposta)
        : [...respostasMultiplas, resposta];
      setRespostasMultiplas(novasRespostasMultiplas);
    } else {
      setRespostaSelecionada(resposta);
    }
  };

  const confirmarResposta = () => {
    // Iniciar timer na primeira resposta
    iniciarTimer();

    const questao = questoesAtivas[questaoAtual];
    let respostaFinal;

    if (questao.tipo === 'multiplas_corretas') {
      respostaFinal = respostasMultiplas.sort();
    } else {
      respostaFinal = respostaSelecionada;
    }

    setRespostas({
      ...respostas,
      [questaoAtual]: {
        resposta: respostaFinal,
        correta: verificarResposta(questao, respostaFinal)
      }
    });

    setMostrarResultado(true);
  };

  const verificarResposta = (questao, resposta) => {
    if (questao.tipo === 'verdadeiro_falso') {
      return resposta === questao.resposta_correta;
    } else if (questao.tipo === 'multiplas_corretas') {
      const respostasCorretas = questao.respostas_corretas.sort();
      return JSON.stringify(resposta) === JSON.stringify(respostasCorretas);
    } else {
      return resposta === questao.resposta_correta;
    }
  };

  const proximaQuestao = () => {
    if (questaoAtual < questoesAtivas.length - 1) {
      setQuestaoAtual(questaoAtual + 1);
      setMostrarResultado(false);
      setRespostaSelecionada(null);
      setRespostasMultiplas([]);
    } else {
      setQuizFinalizado(true);
      setTimerAtivo(false);
    }
  };

  const calcularEstatisticas = () => {
    const totalQuestoes = questoesAtivas.length;
    const acertos = Object.values(respostas).filter(r => r.correta).length;
    const erros = totalQuestoes - acertos;
    const porcentagem = Math.round((acertos / totalQuestoes) * 100);

    const categorias = {};
    questoesAtivas.forEach((questao, index) => {
      if (!categorias[questao.categoria]) {
        categorias[questao.categoria] = { total: 0, acertos: 0 };
      }
      categorias[questao.categoria].total++;
      if (respostas[index]?.correta) {
        categorias[questao.categoria].acertos++;
      }
    });

    return { totalQuestoes, acertos, erros, porcentagem, categorias };
  };

  const getRecomendacoes = (categorias) => {
    const recomendacoes = [];
    Object.entries(categorias).forEach(([categoria, stats]) => {
      const porcentagemCategoria = (stats.acertos / stats.total) * 100;
      if (porcentagemCategoria < 70) {
        recomendacoes.push({
          categoria,
          porcentagem: Math.round(porcentagemCategoria),
          sugestao: getsugestaoEstudo(categoria)
        });
      }
    });
    return recomendacoes;
  };

  const getsugestaoEstudo = (categoria) => {
    const sugestoes = {
      "Câncer de Colo de Útero": "Revise anatomia cervical, HPV, proteínas E6/E7, classificação NIC e Sistema Bethesda",
      "Câncer de Próstata": "Estude anatomia prostática, PSA, Escore de Gleason, fusão TMPRSS2-ERG e terapia hormonal",
      "Leucemias": "Foque em classificação, cromossomo Filadélfia, BCR-ABL, diferenças entre aguda/crônica",
      "Câncer Colorretal": "Revise anatomia do cólon, sequência adenoma-carcinoma, rastreamento e estadiamento TNM",
      "Ciclo Celular": "Estude fases do ciclo, checkpoints, p53, Rb, proto-oncogenes e genes supressores"
    };
    return sugestoes[categoria] || "Revise os conceitos fundamentais desta área";
  };

  if (questoesAtivas.length === 0) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (quizFinalizado) {
    const stats = calcularEstatisticas();
    const recomendacoes = getRecomendacoes(stats.categorias);
    const tempoGasto = 40 * 60 - tempoRestante;
    const minutosTotais = Math.floor(tempoGasto / 60);
    const segundosTotais = tempoGasto % 60;

    return (
      <div className="max-w-4xl mx-auto p-6 space-y-6">
  
      {/* Painel de Configurações */}
      <div className="mb-6 p-4 border rounded bg-white shadow">
        <div className="flex items-center justify-between">
          <h3 className="font-semibold">Configurar Quiz</h3>
          <button className="underline" onClick={() => setShowPainel(v=>!v)}>{showPainel ? 'Ocultar' : 'Mostrar'}</button>
        </div>
        {showPainel && (
        <div className="mt-4 grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="block text-sm font-medium mb-1">Quantidade de questões</label>
            <input type="number" min={1} max={questoes.length} value={quantidade} onChange={e=>setQuantidade(e.target.value)} className="w-full border rounded px-3 py-2" />
            <p className="text-xs mt-1">Disponíveis com filtro: {disponiveisFiltrados}</p>
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">Dificuldades</label>
            <div className="flex flex-col gap-2">
              {['baixa','média','alta'].map(dif => (
                <button key={dif} onClick={() => toggleDificuldade(dif)} className={`flex justify-between px-3 py-1 border rounded text-sm ${dificuldadesSelecionadas.includes(dif) ? 'bg-blue-600 text-white' : 'bg-white'}`}>
                  <span className="capitalize">{dif}</span>
                  <span className="opacity-80">{contagensPorDificuldade[dif]} questões</span>
                </button>
              ))}
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">Temas (categorias)</label>
            <div className="max-h-40 overflow-auto border rounded p-2 space-y-1 bg-white">
              {todasCategorias.map(cat => (
                <label key={cat} className="flex items-center justify-between gap-2 text-sm">
                  <span className="flex items-center gap-2">
                    <input type="checkbox" checked={categoriasSelecionadas.includes(cat)} onChange={() => toggleCategoria(cat)} />
                    <span>{cat}</span>
                  </span>
                  <span className="opacity-80 text-xs">
                    {contagensPorCategoria[cat]?.total || 0} total — baixa: {contagensPorCategoria[cat]?.baixa || 0}, média: {contagensPorCategoria[cat]?.média || 0}, alta: {contagensPorCategoria[cat]?.alta || 0}
                  </span>
                </label>
              ))}
            </div>
          </div>
        </div>
        )}
        <div className="mt-4 flex gap-3">
          <button onClick={aplicarFiltros} className="px-3 py-2 border rounded bg-blue-600 text-white">Aplicar filtros e reiniciar</button>
          <button onClick={resetPreferencias} className="px-3 py-2 border rounded">Restaurar padrão</button>
        </div>
      </div>

      <Card className="text-center">
          <CardHeader>
            <div className="flex justify-center mb-4">
              {tempoRestante === 0 ? (
                <AlertTriangle className="h-16 w-16 text-red-500" />
              ) : (
                <Trophy className="h-16 w-16 text-yellow-500" />
              )}
            </div>
            <CardTitle className="text-3xl">
              {tempoRestante === 0 ? "Tempo Esgotado!" : "Quiz Finalizado!"}
            </CardTitle>
            {tempoRestante === 0 && (
              <p className="text-red-600 mt-2">O tempo de 40 minutos foi esgotado.</p>
            )}
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="bg-green-50 p-4 rounded-lg">
                <div className="text-2xl font-bold text-green-600">{stats.acertos}</div>
                <div className="text-sm text-green-700">Acertos</div>
              </div>
              <div className="bg-red-50 p-4 rounded-lg">
                <div className="text-2xl font-bold text-red-600">{stats.erros}</div>
                <div className="text-sm text-red-700">Erros</div>
              </div>
              <div className="bg-blue-50 p-4 rounded-lg">
                <div className="text-2xl font-bold text-blue-600">{stats.porcentagem}%</div>
                <div className="text-sm text-blue-700">Aproveitamento</div>
              </div>
              <div className="bg-purple-50 p-4 rounded-lg">
                <div className="text-2xl font-bold text-purple-600">
                  {minutosTotais}:{segundosTotais.toString().padStart(2, '0')}
                </div>
                <div className="text-sm text-purple-700">Tempo Gasto</div>
              </div>
            </div>

            <div className="space-y-4">
              <h3 className="text-xl font-semibold flex items-center gap-2">
                <Target className="h-5 w-5" />
                Desempenho por Categoria
              </h3>
              {Object.entries(stats.categorias).map(([categoria, stats]) => (
                <div key={categoria} className="bg-gray-50 p-3 rounded-lg">
                  <div className="flex justify-between items-center mb-2">
                    <span className="font-medium">{categoria}</span>
                    <Badge variant={stats.acertos / stats.total >= 0.7 ? "default" : "destructive"}>
                      {stats.acertos}/{stats.total} ({Math.round((stats.acertos / stats.total) * 100)}%)
                    </Badge>
                  </div>
                  <Progress value={(stats.acertos / stats.total) * 100} className="h-2" />
                </div>
              ))}
            </div>

            {recomendacoes.length > 0 && (
              <div className="space-y-4">
                <h3 className="text-xl font-semibold flex items-center gap-2">
                  <BookOpen className="h-5 w-5" />
                  Recomendações de Estudo
                </h3>
                {recomendacoes.map((rec, index) => (
                  <div key={index} className="bg-yellow-50 p-4 rounded-lg border-l-4 border-yellow-400">
                    <div className="font-medium text-yellow-800">{rec.categoria} ({rec.porcentagem}%)</div>
                    <div className="text-sm text-yellow-700 mt-1">{rec.sugestao}</div>
                  </div>
                ))}
              </div>
            )}

            <Button onClick={iniciarNovoQuiz} className="w-full" size="lg">
              <RotateCcw className="h-4 w-4 mr-2" />
              Novo Quiz
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const questao = questoesAtivas[questaoAtual];
  const progresso = ((questaoAtual + 1) / questoesAtivas.length) * 100;

  return (
    <div className="max-w-4xl mx-auto p-6 space-y-6">
      <div className="flex justify-between items-center">
        <Badge variant="outline">
          Questão {questaoAtual + 1} de {questoesAtivas.length}
        </Badge>
        <div className="flex items-center gap-4">
          {timerIniciado && (
            <div className={`flex items-center gap-2 px-3 py-1 rounded-lg ${
              tempoRestante < 300 ? 'bg-red-50 text-red-700' : 
              tempoRestante < 600 ? 'bg-yellow-50 text-yellow-700' : 
              'bg-blue-50 text-blue-700'
            }`}>
              <Clock className="h-4 w-4" />
              <span className="font-mono font-semibold">
                {formatarTempo(tempoRestante)}
              </span>
            </div>
          )}
          <Badge>{questao.categoria}</Badge>
        </div>
      </div>

      {!timerIniciado && (
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-4">
          <div className="flex items-center gap-2 text-blue-800">
            <Clock className="h-5 w-5" />
            <span className="font-semibold">Timer de 40 minutos</span>
          </div>
          <p className="text-blue-700 text-sm mt-1">
            O cronômetro iniciará automaticamente quando você responder a primeira questão.
          </p>
        </div>
      )}

      <Progress value={progresso} className="h-2" />

      <Card>
        <CardHeader>
          <CardTitle className="text-xl">{questao.pergunta}</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {questao.tipo === 'verdadeiro_falso' ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <Button
                variant={respostaSelecionada === true ? "default" : "outline"}
                onClick={() => handleResposta(true)}
                disabled={mostrarResultado}
                className="p-4 h-auto text-left justify-start"
              >
                Verdadeiro
              </Button>
              <Button
                variant={respostaSelecionada === false ? "default" : "outline"}
                onClick={() => handleResposta(false)}
                disabled={mostrarResultado}
                className="p-4 h-auto text-left justify-start"
              >
                Falso
              </Button>
            </div>
          ) : (
            <div className="space-y-3">
              {questao.tipo === 'multiplas_corretas' && (
                <div className="text-sm text-gray-600 bg-blue-50 p-2 rounded">
                  💡 Esta questão pode ter múltiplas respostas corretas. Selecione todas as opções que se aplicam.
                </div>
              )}
              {questao.opcoes.map((opcao) => (
                <Button
                  key={opcao.letra}
                  variant={
                    questao.tipo === 'multiplas_corretas'
                      ? respostasMultiplas.includes(opcao.letra) ? "default" : "outline"
                      : respostaSelecionada === opcao.letra ? "default" : "outline"
                  }
                  onClick={() => handleResposta(opcao.letra)}
                  disabled={mostrarResultado}
                  className="w-full p-4 h-auto text-left justify-start whitespace-normal break-words"
                >
                  <span className="font-bold mr-3 flex-shrink-0">{opcao.letra})</span>
                  <span className="break-words">{opcao.texto}</span>
                </Button>
              ))}
            </div>
          )}

          {mostrarResultado && (
            <div className="mt-6 p-4 rounded-lg border-l-4 border-blue-400 bg-blue-50">
              <div className="flex items-center gap-2 mb-2">
                {respostas[questaoAtual]?.correta ? (
                  <CheckCircle className="h-5 w-5 text-green-600" />
                ) : (
                  <XCircle className="h-5 w-5 text-red-600" />
                )}
                <span className="font-semibold">
                  {respostas[questaoAtual]?.correta ? "Correto!" : "Incorreto"}
                </span>
              </div>
              <div className="text-sm text-gray-700">
                <strong>Resposta correta:</strong>{" "}
                {questao.tipo === 'verdadeiro_falso'
                  ? questao.resposta_correta ? "Verdadeiro" : "Falso"
                  : questao.tipo === 'multiplas_corretas'
                  ? questao.respostas_corretas.join(", ")
                  : questao.resposta_correta}
              </div>
              <div className="mt-2 text-sm text-gray-700">
                <strong>Explicação:</strong> {questao.explicacao}
              </div>
            </div>
          )}

          <div className="flex justify-between pt-4">
            {!mostrarResultado ? (
              <Button
                onClick={confirmarResposta}
                disabled={
                  questao.tipo === 'multiplas_corretas'
                    ? respostasMultiplas.length === 0
                    : respostaSelecionada === null
                }
                className="ml-auto"
              >
                Confirmar Resposta
              </Button>
            ) : (
              <Button onClick={proximaQuestao} className="ml-auto">
                {questaoAtual < questoesAtivas.length - 1 ? "Próxima Questão" : "Ver Resultado Final"}
              </Button>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default Quiz;

