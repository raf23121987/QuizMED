export const QUESTOES_POR_QUIZ = 30;
