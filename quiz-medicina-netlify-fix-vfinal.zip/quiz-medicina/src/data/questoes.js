export const questoes = [
  {
    "id": 1,
    "categoria": "Neoplasias & Ciclo Celular (SP 1.1)",
    "complexidade": "média",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 1 de Neoplasias & Ciclo Celular (SP 1.1)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 2,
    "categoria": "Neoplasias & Ciclo Celular (SP 1.1)",
    "complexidade": "baixa",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 2 de Neoplasias & Ciclo Celular (SP 1.1)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 3,
    "categoria": "Neoplasias & Ciclo Celular (SP 1.1)",
    "complexidade": "média",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 3 de Neoplasias & Ciclo Celular (SP 1.1)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 4,
    "categoria": "Neoplasias & Ciclo Celular (SP 1.1)",
    "complexidade": "baixa",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 4 de Neoplasias & Ciclo Celular (SP 1.1)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 5,
    "categoria": "Neoplasias & Ciclo Celular (SP 1.1)",
    "complexidade": "média",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 5 de Neoplasias & Ciclo Celular (SP 1.1)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 6,
    "categoria": "Neoplasias & Ciclo Celular (SP 1.1)",
    "complexidade": "média",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 6 de Neoplasias & Ciclo Celular (SP 1.1)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 7,
    "categoria": "Neoplasias & Ciclo Celular (SP 1.1)",
    "complexidade": "baixa",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 7 de Neoplasias & Ciclo Celular (SP 1.1)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 8,
    "categoria": "Neoplasias & Ciclo Celular (SP 1.1)",
    "complexidade": "baixa",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 8 de Neoplasias & Ciclo Celular (SP 1.1)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 9,
    "categoria": "Neoplasias & Ciclo Celular (SP 1.1)",
    "complexidade": "baixa",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 9 de Neoplasias & Ciclo Celular (SP 1.1)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 10,
    "categoria": "Neoplasias & Ciclo Celular (SP 1.1)",
    "complexidade": "média",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 10 de Neoplasias & Ciclo Celular (SP 1.1)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 11,
    "categoria": "Neoplasias & Ciclo Celular (SP 1.1)",
    "complexidade": "média",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 11 de Neoplasias & Ciclo Celular (SP 1.1)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 12,
    "categoria": "Neoplasias & Ciclo Celular (SP 1.1)",
    "complexidade": "alta",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 12 de Neoplasias & Ciclo Celular (SP 1.1)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 13,
    "categoria": "Neoplasias & Ciclo Celular (SP 1.1)",
    "complexidade": "alta",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 13 de Neoplasias & Ciclo Celular (SP 1.1)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 14,
    "categoria": "Neoplasias & Ciclo Celular (SP 1.1)",
    "complexidade": "alta",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 14 de Neoplasias & Ciclo Celular (SP 1.1)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 15,
    "categoria": "Neoplasias & Ciclo Celular (SP 1.1)",
    "complexidade": "alta",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 15 de Neoplasias & Ciclo Celular (SP 1.1)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 16,
    "categoria": "Neoplasias & Ciclo Celular (SP 1.1)",
    "complexidade": "média",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 16 de Neoplasias & Ciclo Celular (SP 1.1)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 17,
    "categoria": "Neoplasias & Ciclo Celular (SP 1.1)",
    "complexidade": "alta",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 17 de Neoplasias & Ciclo Celular (SP 1.1)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 18,
    "categoria": "Neoplasias & Ciclo Celular (SP 1.1)",
    "complexidade": "alta",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 18 de Neoplasias & Ciclo Celular (SP 1.1)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 19,
    "categoria": "Neoplasias & Ciclo Celular (SP 1.1)",
    "complexidade": "média",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 19 de Neoplasias & Ciclo Celular (SP 1.1)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 20,
    "categoria": "Neoplasias & Ciclo Celular (SP 1.1)",
    "complexidade": "baixa",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 20 de Neoplasias & Ciclo Celular (SP 1.1)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 21,
    "categoria": "Neoplasias & Ciclo Celular (SP 1.1)",
    "complexidade": "alta",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 21 de Neoplasias & Ciclo Celular (SP 1.1)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 22,
    "categoria": "Neoplasias & Ciclo Celular (SP 1.1)",
    "complexidade": "alta",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 22 de Neoplasias & Ciclo Celular (SP 1.1)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 23,
    "categoria": "Neoplasias & Ciclo Celular (SP 1.1)",
    "complexidade": "média",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 23 de Neoplasias & Ciclo Celular (SP 1.1)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 24,
    "categoria": "Neoplasias & Ciclo Celular (SP 1.1)",
    "complexidade": "alta",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 24 de Neoplasias & Ciclo Celular (SP 1.1)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 25,
    "categoria": "Neoplasias & Ciclo Celular (SP 1.1)",
    "complexidade": "alta",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 25 de Neoplasias & Ciclo Celular (SP 1.1)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 26,
    "categoria": "Neoplasias & Ciclo Celular (SP 1.1)",
    "complexidade": "alta",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 26 de Neoplasias & Ciclo Celular (SP 1.1)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 27,
    "categoria": "Neoplasias & Ciclo Celular (SP 1.1)",
    "complexidade": "baixa",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 27 de Neoplasias & Ciclo Celular (SP 1.1)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 28,
    "categoria": "Neoplasias & Ciclo Celular (SP 1.1)",
    "complexidade": "média",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 28 de Neoplasias & Ciclo Celular (SP 1.1)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 29,
    "categoria": "Neoplasias & Ciclo Celular (SP 1.1)",
    "complexidade": "baixa",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 29 de Neoplasias & Ciclo Celular (SP 1.1)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 30,
    "categoria": "Neoplasias & Ciclo Celular (SP 1.1)",
    "complexidade": "baixa",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 30 de Neoplasias & Ciclo Celular (SP 1.1)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 31,
    "categoria": "Câncer de Próstata (SP 1.2)",
    "complexidade": "média",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 1 de Câncer de Próstata (SP 1.2)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 32,
    "categoria": "Câncer de Próstata (SP 1.2)",
    "complexidade": "baixa",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 2 de Câncer de Próstata (SP 1.2)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 33,
    "categoria": "Câncer de Próstata (SP 1.2)",
    "complexidade": "média",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 3 de Câncer de Próstata (SP 1.2)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 34,
    "categoria": "Câncer de Próstata (SP 1.2)",
    "complexidade": "baixa",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 4 de Câncer de Próstata (SP 1.2)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 35,
    "categoria": "Câncer de Próstata (SP 1.2)",
    "complexidade": "alta",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 5 de Câncer de Próstata (SP 1.2)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 36,
    "categoria": "Câncer de Próstata (SP 1.2)",
    "complexidade": "média",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 6 de Câncer de Próstata (SP 1.2)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 37,
    "categoria": "Câncer de Próstata (SP 1.2)",
    "complexidade": "média",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 7 de Câncer de Próstata (SP 1.2)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 38,
    "categoria": "Câncer de Próstata (SP 1.2)",
    "complexidade": "média",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 8 de Câncer de Próstata (SP 1.2)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 39,
    "categoria": "Câncer de Próstata (SP 1.2)",
    "complexidade": "média",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 9 de Câncer de Próstata (SP 1.2)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 40,
    "categoria": "Câncer de Próstata (SP 1.2)",
    "complexidade": "alta",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 10 de Câncer de Próstata (SP 1.2)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 41,
    "categoria": "Câncer de Próstata (SP 1.2)",
    "complexidade": "média",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 11 de Câncer de Próstata (SP 1.2)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 42,
    "categoria": "Câncer de Próstata (SP 1.2)",
    "complexidade": "baixa",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 12 de Câncer de Próstata (SP 1.2)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 43,
    "categoria": "Câncer de Próstata (SP 1.2)",
    "complexidade": "alta",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 13 de Câncer de Próstata (SP 1.2)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 44,
    "categoria": "Câncer de Próstata (SP 1.2)",
    "complexidade": "média",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 14 de Câncer de Próstata (SP 1.2)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 45,
    "categoria": "Câncer de Próstata (SP 1.2)",
    "complexidade": "baixa",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 15 de Câncer de Próstata (SP 1.2)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 46,
    "categoria": "Câncer de Próstata (SP 1.2)",
    "complexidade": "média",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 16 de Câncer de Próstata (SP 1.2)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 47,
    "categoria": "Câncer de Próstata (SP 1.2)",
    "complexidade": "alta",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 17 de Câncer de Próstata (SP 1.2)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 48,
    "categoria": "Câncer de Próstata (SP 1.2)",
    "complexidade": "alta",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 18 de Câncer de Próstata (SP 1.2)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 49,
    "categoria": "Câncer de Próstata (SP 1.2)",
    "complexidade": "baixa",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 19 de Câncer de Próstata (SP 1.2)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 50,
    "categoria": "Câncer de Próstata (SP 1.2)",
    "complexidade": "alta",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 20 de Câncer de Próstata (SP 1.2)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 51,
    "categoria": "Câncer de Próstata (SP 1.2)",
    "complexidade": "baixa",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 21 de Câncer de Próstata (SP 1.2)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 52,
    "categoria": "Câncer de Próstata (SP 1.2)",
    "complexidade": "baixa",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 22 de Câncer de Próstata (SP 1.2)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 53,
    "categoria": "Câncer de Próstata (SP 1.2)",
    "complexidade": "alta",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 23 de Câncer de Próstata (SP 1.2)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 54,
    "categoria": "Câncer de Próstata (SP 1.2)",
    "complexidade": "alta",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 24 de Câncer de Próstata (SP 1.2)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 55,
    "categoria": "Câncer de Próstata (SP 1.2)",
    "complexidade": "alta",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 25 de Câncer de Próstata (SP 1.2)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 56,
    "categoria": "Câncer de Próstata (SP 1.2)",
    "complexidade": "alta",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 26 de Câncer de Próstata (SP 1.2)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 57,
    "categoria": "Câncer de Próstata (SP 1.2)",
    "complexidade": "média",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 27 de Câncer de Próstata (SP 1.2)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 58,
    "categoria": "Câncer de Próstata (SP 1.2)",
    "complexidade": "média",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 28 de Câncer de Próstata (SP 1.2)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 59,
    "categoria": "Câncer de Próstata (SP 1.2)",
    "complexidade": "média",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 29 de Câncer de Próstata (SP 1.2)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 60,
    "categoria": "Câncer de Próstata (SP 1.2)",
    "complexidade": "baixa",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 30 de Câncer de Próstata (SP 1.2)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 61,
    "categoria": "Leucemias (SP 1.3)",
    "complexidade": "média",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 1 de Leucemias (SP 1.3)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 62,
    "categoria": "Leucemias (SP 1.3)",
    "complexidade": "média",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 2 de Leucemias (SP 1.3)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 63,
    "categoria": "Leucemias (SP 1.3)",
    "complexidade": "alta",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 3 de Leucemias (SP 1.3)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 64,
    "categoria": "Leucemias (SP 1.3)",
    "complexidade": "alta",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 4 de Leucemias (SP 1.3)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 65,
    "categoria": "Leucemias (SP 1.3)",
    "complexidade": "alta",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 5 de Leucemias (SP 1.3)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 66,
    "categoria": "Leucemias (SP 1.3)",
    "complexidade": "baixa",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 6 de Leucemias (SP 1.3)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 67,
    "categoria": "Leucemias (SP 1.3)",
    "complexidade": "alta",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 7 de Leucemias (SP 1.3)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 68,
    "categoria": "Leucemias (SP 1.3)",
    "complexidade": "média",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 8 de Leucemias (SP 1.3)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 69,
    "categoria": "Leucemias (SP 1.3)",
    "complexidade": "média",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 9 de Leucemias (SP 1.3)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 70,
    "categoria": "Leucemias (SP 1.3)",
    "complexidade": "média",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 10 de Leucemias (SP 1.3)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 71,
    "categoria": "Leucemias (SP 1.3)",
    "complexidade": "alta",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 11 de Leucemias (SP 1.3)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 72,
    "categoria": "Leucemias (SP 1.3)",
    "complexidade": "alta",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 12 de Leucemias (SP 1.3)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 73,
    "categoria": "Leucemias (SP 1.3)",
    "complexidade": "baixa",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 13 de Leucemias (SP 1.3)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 74,
    "categoria": "Leucemias (SP 1.3)",
    "complexidade": "baixa",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 14 de Leucemias (SP 1.3)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 75,
    "categoria": "Leucemias (SP 1.3)",
    "complexidade": "alta",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 15 de Leucemias (SP 1.3)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 76,
    "categoria": "Leucemias (SP 1.3)",
    "complexidade": "baixa",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 16 de Leucemias (SP 1.3)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 77,
    "categoria": "Leucemias (SP 1.3)",
    "complexidade": "média",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 17 de Leucemias (SP 1.3)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 78,
    "categoria": "Leucemias (SP 1.3)",
    "complexidade": "alta",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 18 de Leucemias (SP 1.3)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 79,
    "categoria": "Leucemias (SP 1.3)",
    "complexidade": "alta",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 19 de Leucemias (SP 1.3)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 80,
    "categoria": "Leucemias (SP 1.3)",
    "complexidade": "média",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 20 de Leucemias (SP 1.3)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 81,
    "categoria": "Leucemias (SP 1.3)",
    "complexidade": "alta",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 21 de Leucemias (SP 1.3)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 82,
    "categoria": "Leucemias (SP 1.3)",
    "complexidade": "alta",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 22 de Leucemias (SP 1.3)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 83,
    "categoria": "Leucemias (SP 1.3)",
    "complexidade": "média",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 23 de Leucemias (SP 1.3)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 84,
    "categoria": "Leucemias (SP 1.3)",
    "complexidade": "baixa",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 24 de Leucemias (SP 1.3)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 85,
    "categoria": "Leucemias (SP 1.3)",
    "complexidade": "alta",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 25 de Leucemias (SP 1.3)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 86,
    "categoria": "Leucemias (SP 1.3)",
    "complexidade": "média",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 26 de Leucemias (SP 1.3)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 87,
    "categoria": "Leucemias (SP 1.3)",
    "complexidade": "baixa",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 27 de Leucemias (SP 1.3)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 88,
    "categoria": "Leucemias (SP 1.3)",
    "complexidade": "baixa",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 28 de Leucemias (SP 1.3)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 89,
    "categoria": "Leucemias (SP 1.3)",
    "complexidade": "média",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 29 de Leucemias (SP 1.3)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 90,
    "categoria": "Leucemias (SP 1.3)",
    "complexidade": "baixa",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 30 de Leucemias (SP 1.3)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 91,
    "categoria": "Câncer Colorretal & Pólipos (SP 1.4)",
    "complexidade": "alta",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 1 de Câncer Colorretal & Pólipos (SP 1.4)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 92,
    "categoria": "Câncer Colorretal & Pólipos (SP 1.4)",
    "complexidade": "alta",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 2 de Câncer Colorretal & Pólipos (SP 1.4)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 93,
    "categoria": "Câncer Colorretal & Pólipos (SP 1.4)",
    "complexidade": "baixa",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 3 de Câncer Colorretal & Pólipos (SP 1.4)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 94,
    "categoria": "Câncer Colorretal & Pólipos (SP 1.4)",
    "complexidade": "baixa",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 4 de Câncer Colorretal & Pólipos (SP 1.4)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 95,
    "categoria": "Câncer Colorretal & Pólipos (SP 1.4)",
    "complexidade": "baixa",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 5 de Câncer Colorretal & Pólipos (SP 1.4)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 96,
    "categoria": "Câncer Colorretal & Pólipos (SP 1.4)",
    "complexidade": "baixa",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 6 de Câncer Colorretal & Pólipos (SP 1.4)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 97,
    "categoria": "Câncer Colorretal & Pólipos (SP 1.4)",
    "complexidade": "média",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 7 de Câncer Colorretal & Pólipos (SP 1.4)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 98,
    "categoria": "Câncer Colorretal & Pólipos (SP 1.4)",
    "complexidade": "média",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 8 de Câncer Colorretal & Pólipos (SP 1.4)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 99,
    "categoria": "Câncer Colorretal & Pólipos (SP 1.4)",
    "complexidade": "média",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 9 de Câncer Colorretal & Pólipos (SP 1.4)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 100,
    "categoria": "Câncer Colorretal & Pólipos (SP 1.4)",
    "complexidade": "baixa",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 10 de Câncer Colorretal & Pólipos (SP 1.4)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 101,
    "categoria": "Câncer Colorretal & Pólipos (SP 1.4)",
    "complexidade": "média",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 11 de Câncer Colorretal & Pólipos (SP 1.4)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 102,
    "categoria": "Câncer Colorretal & Pólipos (SP 1.4)",
    "complexidade": "alta",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 12 de Câncer Colorretal & Pólipos (SP 1.4)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 103,
    "categoria": "Câncer Colorretal & Pólipos (SP 1.4)",
    "complexidade": "baixa",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 13 de Câncer Colorretal & Pólipos (SP 1.4)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 104,
    "categoria": "Câncer Colorretal & Pólipos (SP 1.4)",
    "complexidade": "baixa",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 14 de Câncer Colorretal & Pólipos (SP 1.4)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 105,
    "categoria": "Câncer Colorretal & Pólipos (SP 1.4)",
    "complexidade": "média",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 15 de Câncer Colorretal & Pólipos (SP 1.4)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 106,
    "categoria": "Câncer Colorretal & Pólipos (SP 1.4)",
    "complexidade": "média",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 16 de Câncer Colorretal & Pólipos (SP 1.4)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 107,
    "categoria": "Câncer Colorretal & Pólipos (SP 1.4)",
    "complexidade": "média",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 17 de Câncer Colorretal & Pólipos (SP 1.4)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 108,
    "categoria": "Câncer Colorretal & Pólipos (SP 1.4)",
    "complexidade": "baixa",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 18 de Câncer Colorretal & Pólipos (SP 1.4)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 109,
    "categoria": "Câncer Colorretal & Pólipos (SP 1.4)",
    "complexidade": "alta",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 19 de Câncer Colorretal & Pólipos (SP 1.4)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 110,
    "categoria": "Câncer Colorretal & Pólipos (SP 1.4)",
    "complexidade": "média",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 20 de Câncer Colorretal & Pólipos (SP 1.4)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 111,
    "categoria": "Câncer Colorretal & Pólipos (SP 1.4)",
    "complexidade": "baixa",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 21 de Câncer Colorretal & Pólipos (SP 1.4)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 112,
    "categoria": "Câncer Colorretal & Pólipos (SP 1.4)",
    "complexidade": "alta",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 22 de Câncer Colorretal & Pólipos (SP 1.4)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 113,
    "categoria": "Câncer Colorretal & Pólipos (SP 1.4)",
    "complexidade": "alta",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 23 de Câncer Colorretal & Pólipos (SP 1.4)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 114,
    "categoria": "Câncer Colorretal & Pólipos (SP 1.4)",
    "complexidade": "média",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 24 de Câncer Colorretal & Pólipos (SP 1.4)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 115,
    "categoria": "Câncer Colorretal & Pólipos (SP 1.4)",
    "complexidade": "alta",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 25 de Câncer Colorretal & Pólipos (SP 1.4)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 116,
    "categoria": "Câncer Colorretal & Pólipos (SP 1.4)",
    "complexidade": "baixa",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 26 de Câncer Colorretal & Pólipos (SP 1.4)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 117,
    "categoria": "Câncer Colorretal & Pólipos (SP 1.4)",
    "complexidade": "baixa",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 27 de Câncer Colorretal & Pólipos (SP 1.4)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 118,
    "categoria": "Câncer Colorretal & Pólipos (SP 1.4)",
    "complexidade": "média",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 28 de Câncer Colorretal & Pólipos (SP 1.4)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 119,
    "categoria": "Câncer Colorretal & Pólipos (SP 1.4)",
    "complexidade": "baixa",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 29 de Câncer Colorretal & Pólipos (SP 1.4)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 120,
    "categoria": "Câncer Colorretal & Pólipos (SP 1.4)",
    "complexidade": "alta",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 30 de Câncer Colorretal & Pólipos (SP 1.4)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 121,
    "categoria": "Câncer de Colo de Útero (Integração NCS/SP)",
    "complexidade": "baixa",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 1 de Câncer de Colo de Útero (Integração NCS/SP)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 122,
    "categoria": "Câncer de Colo de Útero (Integração NCS/SP)",
    "complexidade": "alta",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 2 de Câncer de Colo de Útero (Integração NCS/SP)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 123,
    "categoria": "Câncer de Colo de Útero (Integração NCS/SP)",
    "complexidade": "alta",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 3 de Câncer de Colo de Útero (Integração NCS/SP)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 124,
    "categoria": "Câncer de Colo de Útero (Integração NCS/SP)",
    "complexidade": "média",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 4 de Câncer de Colo de Útero (Integração NCS/SP)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 125,
    "categoria": "Câncer de Colo de Útero (Integração NCS/SP)",
    "complexidade": "baixa",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 5 de Câncer de Colo de Útero (Integração NCS/SP)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 126,
    "categoria": "Câncer de Colo de Útero (Integração NCS/SP)",
    "complexidade": "média",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 6 de Câncer de Colo de Útero (Integração NCS/SP)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 127,
    "categoria": "Câncer de Colo de Útero (Integração NCS/SP)",
    "complexidade": "baixa",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 7 de Câncer de Colo de Útero (Integração NCS/SP)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 128,
    "categoria": "Câncer de Colo de Útero (Integração NCS/SP)",
    "complexidade": "baixa",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 8 de Câncer de Colo de Útero (Integração NCS/SP)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 129,
    "categoria": "Câncer de Colo de Útero (Integração NCS/SP)",
    "complexidade": "alta",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 9 de Câncer de Colo de Útero (Integração NCS/SP)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 130,
    "categoria": "Câncer de Colo de Útero (Integração NCS/SP)",
    "complexidade": "alta",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 10 de Câncer de Colo de Útero (Integração NCS/SP)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 131,
    "categoria": "Câncer de Colo de Útero (Integração NCS/SP)",
    "complexidade": "baixa",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 11 de Câncer de Colo de Útero (Integração NCS/SP)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 132,
    "categoria": "Câncer de Colo de Útero (Integração NCS/SP)",
    "complexidade": "baixa",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 12 de Câncer de Colo de Útero (Integração NCS/SP)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 133,
    "categoria": "Câncer de Colo de Útero (Integração NCS/SP)",
    "complexidade": "alta",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 13 de Câncer de Colo de Útero (Integração NCS/SP)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 134,
    "categoria": "Câncer de Colo de Útero (Integração NCS/SP)",
    "complexidade": "baixa",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 14 de Câncer de Colo de Útero (Integração NCS/SP)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 135,
    "categoria": "Câncer de Colo de Útero (Integração NCS/SP)",
    "complexidade": "baixa",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 15 de Câncer de Colo de Útero (Integração NCS/SP)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 136,
    "categoria": "Câncer de Colo de Útero (Integração NCS/SP)",
    "complexidade": "média",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 16 de Câncer de Colo de Útero (Integração NCS/SP)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 137,
    "categoria": "Câncer de Colo de Útero (Integração NCS/SP)",
    "complexidade": "média",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 17 de Câncer de Colo de Útero (Integração NCS/SP)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 138,
    "categoria": "Câncer de Colo de Útero (Integração NCS/SP)",
    "complexidade": "alta",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 18 de Câncer de Colo de Útero (Integração NCS/SP)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 139,
    "categoria": "Câncer de Colo de Útero (Integração NCS/SP)",
    "complexidade": "baixa",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 19 de Câncer de Colo de Útero (Integração NCS/SP)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 140,
    "categoria": "Câncer de Colo de Útero (Integração NCS/SP)",
    "complexidade": "alta",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 20 de Câncer de Colo de Útero (Integração NCS/SP)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 141,
    "categoria": "Câncer de Colo de Útero (Integração NCS/SP)",
    "complexidade": "baixa",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 21 de Câncer de Colo de Útero (Integração NCS/SP)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 142,
    "categoria": "Câncer de Colo de Útero (Integração NCS/SP)",
    "complexidade": "alta",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 22 de Câncer de Colo de Útero (Integração NCS/SP)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 143,
    "categoria": "Câncer de Colo de Útero (Integração NCS/SP)",
    "complexidade": "alta",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 23 de Câncer de Colo de Útero (Integração NCS/SP)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 144,
    "categoria": "Câncer de Colo de Útero (Integração NCS/SP)",
    "complexidade": "baixa",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 24 de Câncer de Colo de Útero (Integração NCS/SP)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 145,
    "categoria": "Câncer de Colo de Útero (Integração NCS/SP)",
    "complexidade": "média",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 25 de Câncer de Colo de Útero (Integração NCS/SP)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 146,
    "categoria": "Câncer de Colo de Útero (Integração NCS/SP)",
    "complexidade": "alta",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 26 de Câncer de Colo de Útero (Integração NCS/SP)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 147,
    "categoria": "Câncer de Colo de Útero (Integração NCS/SP)",
    "complexidade": "alta",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 27 de Câncer de Colo de Útero (Integração NCS/SP)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 148,
    "categoria": "Câncer de Colo de Útero (Integração NCS/SP)",
    "complexidade": "baixa",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 28 de Câncer de Colo de Útero (Integração NCS/SP)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 149,
    "categoria": "Câncer de Colo de Útero (Integração NCS/SP)",
    "complexidade": "baixa",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 29 de Câncer de Colo de Útero (Integração NCS/SP)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  },
  {
    "id": 150,
    "categoria": "Câncer de Colo de Útero (Integração NCS/SP)",
    "complexidade": "média",
    "tipo": "multipla_escolha",
    "pergunta": "Questão 30 de Câncer de Colo de Útero (Integração NCS/SP)",
    "opcoes": [
      {
        "letra": "A",
        "texto": "Opção A"
      },
      {
        "letra": "B",
        "texto": "Opção B"
      },
      {
        "letra": "C",
        "texto": "Opção C"
      },
      {
        "letra": "D",
        "texto": "Opção D"
      }
    ],
    "resposta_correta": "A",
    "explicacao": "Explicação resumida baseada nas SPs."
  }
]

export function selecionarQuestoes(qtd = 30, filtro = () => true) {
  const arr = [...questoes].filter(filtro);
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr.slice(0, Math.min(qtd, arr.length));
}

export const DEFAULT_QUESTOES_POR_QUIZ = 30;
